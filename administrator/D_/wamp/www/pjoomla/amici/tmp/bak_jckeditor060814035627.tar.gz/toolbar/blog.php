<?php
/*------------------------------------------------------------------------
# Copyright (C) 2005-2012 WebxSolution Ltd. All Rights Reserved.
# @license - GPLv2.0
# Author: WebxSolution Ltd
# Websites:  http://www.webxsolution.com
# Terms of Use: An extension that is derived from the JoomlaCK editor will only be allowed under the following conditions: http://joomlackeditor.com/terms-of-use
# ------------------------------------------------------------------------*/ 

defined( '_JEXEC' ) or die( 'Restricted access' );

class JCKBlog extends JCKToolbar
{

	//row 1
	var $Cut = 1;
	var $Copy;
	var $Paste;
	var $PasteText;
	var $PasteFromWord;
	var $SelectAll;
	var $sep_1;
	var $SpellChecker;
	var $Scayt;
	

	//row 2
	var $Bold = 2;
	var $Italic;
	var $Underline;
	
	//row 3
	var $NumberedList = 3;
	var $BulletedList;
	var $sep_4;
	var $Outdent;
	var $Indent;
	
	//row 4
	var $Undo = 4;
	var $Redo;
	var $RemoveFormat;
	
	//row 5
	var $JustifyLeft = 5;
	var $JustifyCenter;
	var $JustifyRight;
	var $JustifyBlock;
	
	//row 6
	var $Link = 6;
	var $Unlink;
	
	//row 7
	var $FontSize = 7;
	var $TextColor;
	var $BGColor;
	
	//row 8
	var $Maximize = 8;
	var $sep_6;
	var $About;
	
}



